# Eri Mail — Cloudflare custom-domain setup

Status: preparation only. A domain has not yet been purchased or connected. This repository does not yet provide a functioning custom-domain inbox.

## First step on iPhone
1. Visit https://dash.cloudflare.com/sign-up in Safari.
2. Register with an email address you already control and a unique password.
3. Verify the Cloudflare account using the email Cloudflare sends.
4. Do not send your password, verification codes, API tokens or payment details to anyone.

## Next required user-owned step
Register a domain in your own name and connect its DNS to Cloudflare. Domain registration may cost money and requires the account owner's confirmation.

## Receiving mail
Cloudflare Email Routing requires Cloudflare DNS for the domain. Configure a verified destination address, then enable the catch-all rule. To show mail *inside* Eri Mail, a separate authenticated inbox backend (e.g. Email Worker + durable storage + authenticated API) is required; catch-all forwarding by itself is insufficient.

## Planned iOS changes
- Replace mail.tm domain creation with cryptographically random aliases on the verified custom domain.
- Persist aliases locally and provide copy/share actions.
- Connect to a secure authenticated inbox API; never embed an administrator API token in an IPA.
- Read received messages and display their contents; no automatic OTP extraction is required.
- Keep setup state explicit: never imply an alias can receive mail until routing and backend tests succeed.

Custom-domain email is not Gmail and is not guaranteed to be accepted by third-party registration services.
