# IPA build request

Trigger GitHub Actions to build the uploaded EriMail source archive as an unsigned IPA.
