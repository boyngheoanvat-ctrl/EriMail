# Eri Mail: Gmail + Outlook OAuth setup

Bundle ID: `com.erimail.erimod`

## Google
1. Create a Google Cloud project, configure OAuth consent screen (External, testing users as needed).
2. Enable Gmail API; request the minimum scope `https://www.googleapis.com/auth/gmail.readonly`.
3. Create an iOS OAuth client for bundle `com.erimail.erimod`.
4. Record iOS Client ID and reversed-client-ID URL scheme. Configure them in iOS Info.plist.
5. For production distribution, Google's Gmail restricted-scope verification requirements may apply.

## Microsoft
1. Register Eri Mail in Microsoft Entra App registrations, with personal Microsoft accounts enabled.
2. Add iOS/macOS platform with bundle `com.erimail.erimod`.
3. Record Application (client) ID and generated redirect URI (normally `msauth.com.erimail.erimod://auth`).
4. Add Microsoft Graph delegated permissions `User.Read`, `Mail.Read` and `offline_access` where needed.
5. Use OAuth authorization code with PKCE, system browser, secure token storage, and official Microsoft Graph endpoints.

## Security
Never put a client secret, password, refresh token, or OTP in a repository. iOS client IDs are public identifiers.
Use Keychain for tokens, ASWebAuthenticationSession or supported official SDK, PKCE, and exact redirect URI matching.

## Build status
This file documents prerequisites. Existing app source still uses mail.tm until OAuth client IDs and URL schemes are configured and the OAuth integration is implemented.
