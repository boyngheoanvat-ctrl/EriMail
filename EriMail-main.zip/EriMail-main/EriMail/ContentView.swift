import SwiftUI
import Foundation
import SafariServices
import UniformTypeIdentifiers
import Security

// Independent public-API client for mail.tm and mail.gw.
// Not affiliated with either provider. Both are disposable email services.
struct MailDomain: Decodable { let domain: String }
struct MailAccount: Decodable { let id: String; let address: String }
struct MailToken: Decodable { let token: String }
struct MailAddress: Decodable { let address: String?; let name: String? }
struct MailSummary: Decodable, Identifiable {
    let id: String
    let from: MailAddress?
    let subject: String?
    let intro: String?
    let createdAt: String?
}
struct MailMessage: Decodable {
    let id: String
    let subject: String?
    let text: String?
    let html: [String]?
    let from: MailAddress?
}
struct HydraResponse<T: Decodable>: Decodable {
    let members: [T]
    private enum CodingKeys: String, CodingKey {
        case hydraMember = "hydra:member"
        case member, members, data
    }
    init(from decoder: Decoder) throws {
        if let array = try? [T](from: decoder) {
            members = array
            return
        }
        let container = try decoder.container(keyedBy: CodingKeys.self)
        for key in [CodingKeys.hydraMember, .member, .members, .data] {
            if let value = try? container.decode([T].self, forKey: key) {
                members = value
                return
            }
        }
        throw DecodingError.dataCorruptedError(
            forKey: .hydraMember, in: container,
            debugDescription: "Phản hồi không chứa danh sách dữ liệu hợp lệ."
        )
    }
}
struct APIError: Decodable { let message: String? }

enum MailFailure: LocalizedError {
    case invalidResponse, server(String)
    var errorDescription: String? {
        switch self {
        case .invalidResponse: return "Phản hồi máy chủ không hợp lệ."
        case .server(let message): return message
        }
    }
}

@MainActor final class MailStore: ObservableObject {
    @Published var address = UserDefaults.standard.string(forKey: "eri.mail.address") ?? ""
    @Published var provider = UserDefaults.standard.string(forKey: "eri.mail.provider") ?? "mail.tm"
    @Published var messages: [MailSummary] = []
    @Published var selected: MailMessage?
    @Published var busy = false
    @Published var error: String?
    private var token: String = UserDefaults.standard.string(forKey: "eri.mail.token") ?? ""
    private var base: URL { URL(string: provider == "mail.gw" ? "https://api.mail.gw" : "https://api.mail.tm")! }

    func chooseProvider(_ value: String) {
        guard value == "mail.tm" || value == "mail.gw" else { return }
        if provider != value { reset(); provider = value; UserDefaults.standard.set(value, forKey: "eri.mail.provider") }
    }

    private func request<T: Decodable>(_ path: String, method: String = "GET", body: [String: String]? = nil, authenticated: Bool = false) async throws -> T {
        guard let url = URL(string: path, relativeTo: base) else { throw MailFailure.invalidResponse }
        var req = URLRequest(url: url)
        req.httpMethod = method
        req.timeoutInterval = 25
        req.setValue("application/json", forHTTPHeaderField: "Accept")
        if authenticated { req.setValue("Bearer " + token, forHTTPHeaderField: "Authorization") }
        if let body = body {
            req.setValue("application/json", forHTTPHeaderField: "Content-Type")
            req.httpBody = try JSONSerialization.data(withJSONObject: body)
        }
        let data: Data
        let response: URLResponse
        do {
            (data, response) = try await URLSession.shared.data(for: req)
        } catch {
            throw MailFailure.server("Không kết nối được " + url.host! + ": " + error.localizedDescription + ". Hãy kiểm tra Wi-Fi/4G hoặc đổi dịch vụ.")
        }
        guard let http = response as? HTTPURLResponse else { throw MailFailure.invalidResponse }
        guard (200...299).contains(http.statusCode) else {
            let server = try? JSONDecoder().decode(APIError.self, from: data)
            throw MailFailure.server(server?.message ?? "HTTP \(http.statusCode)")
        }
        do {
            return try JSONDecoder().decode(T.self, from: data)
        } catch {
            let snippet = String(data: data.prefix(250), encoding: .utf8) ?? "(không đọc được)"
            throw MailFailure.server("API trả về dữ liệu không đúng định dạng (HTTP \(http.statusCode)). \(snippet)")
        }
    }

    func createInbox() async {
        guard !busy else { return }
        busy = true; error = nil
        defer { busy = false }
        let original = provider
        do {
            try await registerInbox()
        } catch {
            // Only retry on a connection failure, never on account/API errors.
            let message = error.localizedDescription
            if message.hasPrefix("Không kết nối được ") {
                let fallback = original == "mail.tm" ? "mail.gw" : "mail.tm"
                provider = fallback
                do {
                    try await registerInbox()
                } catch {
                    provider = original
                    self.error = original + ": " + message + "\n" + fallback + ": " + error.localizedDescription
                }
            } else {
                self.error = message
            }
        }
    }

    private func registerInbox() async throws {
        let domains: HydraResponse<MailDomain> = try await request("/domains")
        guard let domain = domains.members.first?.domain else {
            throw MailFailure.server("Không có tên miền khả dụng trên " + provider)
        }
        let username = "eri" + UUID().uuidString.replacingOccurrences(of: "-", with: "").prefix(16).lowercased()
        let password = UUID().uuidString + UUID().uuidString
        let created: MailAccount = try await request("/accounts", method: "POST", body: ["address": "\(username)@\(domain)", "password": password])
        let auth: MailToken = try await request("/token", method: "POST", body: ["address": created.address, "password": password])
        token = auth.token; address = created.address; messages = []; selected = nil
        UserDefaults.standard.set(address, forKey: "eri.mail.address")
        UserDefaults.standard.set(token, forKey: "eri.mail.token")
        UserDefaults.standard.set(provider, forKey: "eri.mail.provider")
        await refresh()
    }

    func refresh() async {
        guard !token.isEmpty else { return }
        do {
            let result: HydraResponse<MailSummary> = try await request("/messages", authenticated: true)
            messages = result.members
            error = nil
        } catch { self.error = error.localizedDescription }
    }

    func open(_ item: MailSummary) async {
        do {
            let result: MailMessage = try await request("/messages/" + item.id, authenticated: true)
            selected = result
            error = nil
        } catch { self.error = error.localizedDescription }
    }

    func reset() {
        token = ""; address = ""; messages = []; selected = nil; error = nil
        UserDefaults.standard.removeObject(forKey: "eri.mail.address")
        UserDefaults.standard.removeObject(forKey: "eri.mail.token")
    }
}

struct ContentView: View {
    @StateObject private var store = MailStore()
    @State private var showingMessage = false
    @AppStorage("eri.mail.mode") private var mode = "gmail"

    private func tabTitle(_ value: String) -> String {
        switch value {
        case "gmail": return "Gmail alias"
        case "temporary": return "Email tạm"
        case "offers": return "Ưu đãi App Store"
        case "ipa": return "Xuất IPA"
        case "tools": return "Công cụ"
        case "certificates": return "Chứng chỉ"
        case "inject": return "Inject Dylib"
        default: return "Eri Mail"
        }
    }

    var body: some View {
        NavigationView {
            VStack(spacing: 0) {
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 8) {
                        ForEach(["gmail", "temporary", "offers", "ipa", "tools", "certificates", "inject"], id: \.self) { value in
                            Button {
                                mode = value
                            } label: {
                                Text(tabTitle(value))
                                    .font(.subheadline.weight(.semibold))
                                    .foregroundColor(mode == value ? .white : .primary)
                                    .padding(.horizontal, 14)
                                    .padding(.vertical, 10)
                                    .background(
                                        RoundedRectangle(cornerRadius: 12)
                                            .fill(mode == value ? Color.blue : Color(.secondarySystemBackground))
                                    )
                            }
                            .buttonStyle(.plain)
                        }
                    }
                    .padding(.horizontal)
                    .padding(.vertical, 8)
                }
                if mode == "gmail" {
                    GmailAliasView()
                } else if mode == "offers" {
                    AppStoreOffersView()
                } else if mode == "ipa" {
                    IPAExportView()
                } else if mode == "tools" {
                    SigningToolsView()
                } else if mode == "certificates" {
                    CertificatesView()
                } else if mode == "inject" {
                    InjectDylibView()
                } else if store.address.isEmpty {
                    CreateInboxView(store: store)
                } else {
                    InboxListView(store: store, showingMessage: $showingMessage)
                }
            }
            .onAppear {
                if mode == "skyworld" || mode == "billing" {
                    mode = "gmail"
                }
            }
            .navigationTitle("Eri Mail")
            .alert("Thông báo", isPresented: Binding<Bool>(
                get: { store.error != nil },
                set: { if !$0 { store.error = nil } }
            )) {
                Button("Đóng", role: .cancel) { store.error = nil }
            } message: {
                Text(store.error ?? "")
            }
            .sheet(isPresented: $showingMessage) {
                MessageDetailView(message: store.selected)
            }
            .task {
                if !store.address.isEmpty { await store.refresh() }
            }
        }
    }
}

// Sky World is a third-party storefront. Open its official website in
// SafariServices so authentication and checkout stay on the retailer's domain.
// No wallet balances, prices, or order results are modified inside Eri Mail.
struct SkyWorldView: View {
    @State private var showingStore = false
    private let storeURL = URL(string: "https://sky-sky-sky.com/")!

    var body: some View {
        ScrollView {
            VStack(spacing: 18) {
                Image(systemName: "bag.fill")
                    .font(.system(size: 58))
                    .foregroundColor(.blue)
                Text("Sky World")
                    .font(.largeTitle.bold())
                Text("Mở cửa hàng thật, đăng nhập tài khoản của bạn, xem ví coin, chọn gói và theo dõi đơn hàng trên Sky World.")
                    .multilineTextAlignment(.center)
                    .foregroundColor(.secondary)
                Button {
                    showingStore = true
                } label: {
                    Label("Mở Sky World trong IPA", systemImage: "safari")
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(.borderedProminent)

                Button {
                    UIApplication.shared.open(storeURL)
                } label: {
                    Label("Mở bằng Safari", systemImage: "arrow.up.right.square")
                }
                Text("Sky World là dịch vụ bên thứ ba. Số dư, giá bán, thanh toán và giao hàng do máy chủ của họ xác nhận. Eri Mail không tự cấp xu hay tài khoản ChatGPT.")
                    .font(.footnote)
                    .multilineTextAlignment(.center)
                    .foregroundColor(.secondary)
            }
            .padding(24)
            .frame(maxWidth: 560)
            .frame(maxWidth: .infinity)
        }
        .sheet(isPresented: $showingStore) {
            SkyWorldSafariView(url: storeURL)
                .ignoresSafeArea()
        }
    }
}

struct SkyWorldSafariView: UIViewControllerRepresentable {
    let url: URL

    func makeUIViewController(context: Context) -> SFSafariViewController {
        SFSafariViewController(url: url)
    }

    func updateUIViewController(_ controller: SFSafariViewController, context: Context) {}
}

struct CreateInboxView: View {
    @ObservedObject var store: MailStore
    var body: some View {
        VStack(spacing: 20) {
            Image(systemName: "envelope.fill")
                .font(.system(size: 72))
                .foregroundColor(.green)
            Text("Eri Mail").font(.largeTitle.bold())
            Text("Email tạm thời miễn phí. Không bảo đảm được các dịch vụ khác chấp nhận.")
                .foregroundColor(.secondary)
                .multilineTextAlignment(.center)
            Picker("Dịch vụ", selection: Binding<String>(
                get: { store.provider },
                set: { store.chooseProvider($0) }
            )) {
                Text("Mail.tm").tag("mail.tm")
                Text("Mail.gw").tag("mail.gw")
            }
            .pickerStyle(.segmented)
            Button("Tạo địa chỉ email") {
                Task { await store.createInbox() }
            }
            .buttonStyle(.borderedProminent)
            .disabled(store.busy)
            if store.busy { ProgressView() }
        }
        .padding()
    }
}

struct InboxListView: View {
    @ObservedObject var store: MailStore
    @Binding var showingMessage: Bool

    var body: some View {
        List {
            Section("Địa chỉ email · " + store.provider) {
                Text(store.address).textSelection(.enabled)
                Button("Sao chép") { UIPasteboard.general.string = store.address }
                Button("Làm mới") { Task { await store.refresh() } }
            }
            Section("Hộp thư đến") {
                if store.messages.isEmpty {
                    Text("Chưa có thư. Kéo xuống để làm mới.")
                        .foregroundColor(.secondary)
                }
                ForEach(store.messages) { item in
                    Button {
                        Task {
                            await store.open(item)
                            if store.selected?.id == item.id { showingMessage = true }
                        }
                    } label: {
                        MailRowView(item: item)
                    }
                }
            }
            Section {
                Button("Đổi email / dịch vụ", role: .destructive) { store.reset() }
            }
        }
        .refreshable { await store.refresh() }
    }
}

struct MailRowView: View {
    let item: MailSummary
    var body: some View {
        VStack(alignment: .leading, spacing: 5) {
            Text(item.from?.address ?? "Người gửi")
                .font(.subheadline).foregroundColor(.secondary)
            Text(item.subject ?? "(Không có tiêu đề)")
                .font(.headline).foregroundColor(.primary)
            Text(item.intro ?? "")
                .font(.footnote).foregroundColor(.secondary).lineLimit(2)
        }
    }
}

struct MessageDetailView: View {
    let message: MailMessage?
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationView {
            ScrollView {
                VStack(alignment: .leading, spacing: 14) {
                    Text(message?.subject ?? "(Không có tiêu đề)")
                        .font(.title2.bold())
                    Text(message?.from?.address ?? "Không rõ")
                        .foregroundColor(.secondary)
                    Divider()
                    Text(message?.text ?? "Không có nội dung văn bản.")
                        .textSelection(.enabled)
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding()
            }
            .navigationTitle("Đọc email")
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Đóng") { dismiss() }
                }
            }
        }
    }
}

 
struct GmailAliasView: View {
    @AppStorage("eri.gmail.base") private var gmail = ""
    @AppStorage("eri.gmail.aliases") private var savedAliases = ""
    @State private var currentAlias = ""
    @State private var showInvalidGmail = false
    @State private var trialLink = ""
    @State private var showDeleteAllAliases = false

    private var aliases: [String] {
        savedAliases.split(separator: "\n").map(String.init)
    }

    var body: some View {
        List {
            Section("Gmail gốc") {
                TextField("Nhập Gmail của bạn", text: $gmail)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
                    .keyboardType(.emailAddress)
                Text("Gmail được lưu trên thiết bị, không đưa vào mã nguồn công khai.")
                    .font(.footnote).foregroundColor(.secondary)
                Text("Địa chỉ phụ nhận thư vào Gmail gốc. Không phải tài khoản Google mới.")
                    .font(.footnote).foregroundColor(.secondary)
            }
            Section("Tạo địa chỉ phụ") {
                if !currentAlias.isEmpty {
                    Text(currentAlias).textSelection(.enabled)
                    Button("Sao chép email") {
                        UIPasteboard.general.string = currentAlias
                    }
                }
                Button("Tạo Gmail alias ngẫu nhiên") { createAlias() }
                    .disabled(!validGmail)
                    .buttonStyle(.borderedProminent)
            }
            Section("Địa chỉ đã tạo") {
                if aliases.isEmpty {
                    Text("Chưa có địa chỉ phụ").foregroundColor(.secondary)
                }
                ForEach(aliases, id: \.self) { alias in
                    HStack {
                        Button(alias) {
                            currentAlias = alias
                            UIPasteboard.general.string = alias
                        }
                        .buttonStyle(.plain)
                        Spacer(minLength: 8)
                        Button(role: .destructive) {
                            deleteAlias(alias)
                        } label: {
                            Image(systemName: "trash")
                                .foregroundColor(.red)
                        }
                        .buttonStyle(.borderless)
                        .accessibilityLabel("Xóa " + alias)
                    }
                }
                .onDelete(perform: deleteAliases)
                if !aliases.isEmpty {
                    Button(role: .destructive) {
                        showDeleteAllAliases = true
                    } label: {
                        Label("Xóa tất cả địa chỉ đã tạo", systemImage: "trash")
                    }
                }
            }
            Section("Tạo Gmail thật qua Google") {
                Text("Mở trang đăng ký chính thức để tạo tài khoản @gmail.com mới. Bạn tự chọn địa chỉ, đặt mật khẩu và hoàn tất bước xác minh của Google.")
                    .font(.footnote)
                    .foregroundColor(.secondary)
                Button {
                    openURL("https://accounts.google.com/signup")
                } label: {
                    Label("Đăng ký Gmail mới", systemImage: "person.crop.circle.badge.plus")
                }
                .buttonStyle(.borderedProminent)
                Text("Gmail alias ở trên chỉ là địa chỉ phụ, không tạo tài khoản Google mới. Eri Mail không thể đăng ký Gmail thay bạn.")
                    .font(.footnote)
                    .foregroundColor(.secondary)
            }
            Section("ChatGPT Plus · 1 Month Free Trial") {
                Button("Mở trang ChatGPT") {
                    openURL("https://chatgpt.com/")
                }
                TextField("Dán link ưu đãi chính thức (https://...)", text: $trialLink)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
                    .keyboardType(.URL)
                Button {
                    if let url = verifiedTrialURL {
                        UIApplication.shared.open(url)
                    }
                } label: {
                    Label("Mở liên kết dùng thử", systemImage: "gift")
                }
                .disabled(verifiedTrialURL == nil)
                Text("Chỉ chấp nhận liên kết HTTPS trên chatgpt.com hoặc openai.com. Gói dùng thử không được tích hợp sẵn; OpenAI xác định điều kiện nhận và thời hạn ưu đãi.")
                    .font(.footnote)
                    .foregroundColor(.secondary)
                Button("Đọc điều kiện dùng thử của OpenAI") {
                    openURL("https://help.openai.com/vi-vn/articles/8381046-chatgpt-promotional-subscriptionsfree-trial-invites-faq")
                }
                Button("Kiểm tra gói ChatGPT") {
                    openURL("https://chatgpt.com/#settings/Subscription")
                }
                Text("Một số ưu đãi cần phương thức thanh toán và có thể tự gia hạn sau thời gian miễn phí. Kiểm tra điều khoản trước khi xác nhận.")
                    .font(.footnote)
                    .foregroundColor(.secondary)
            }
            Section("Đọc email") {
                Button("Mở Gmail") {
                    if let url = URL(string: "https://mail.google.com/mail/u/0/#all") {
                        UIApplication.shared.open(url)
                    }
                }
                Text("Để đọc thư trực tiếp trong Eri Mail cần Google OAuth. Hiện hãy mở ứng dụng Gmail và chọn đúng tài khoản gốc.")
                    .font(.footnote).foregroundColor(.secondary)
                Text("Một số dịch vụ, bao gồm Garena, có thể từ chối dấu + hoặc coi các alias là cùng một tài khoản.")
                    .font(.footnote).foregroundColor(.secondary)
            }
        }
        .confirmationDialog("Xóa toàn bộ Gmail alias đã lưu?", isPresented: $showDeleteAllAliases, titleVisibility: .visible) {
            Button("Xóa tất cả", role: .destructive) {
                savedAliases = ""
                currentAlias = ""
            }
            Button("Hủy", role: .cancel) {}
        } message: {
            Text("Chỉ xóa danh sách alias trong Eri Mail. Không xóa email hay tài khoản Gmail.")
        }
    }

    private func deleteAlias(_ alias: String) {
        savedAliases = aliases.filter { $0 != alias }.joined(separator: "\n")
        if currentAlias == alias { currentAlias = "" }
    }

    private func deleteAliases(at offsets: IndexSet) {
        let current = aliases
        let removed = offsets.map { current[$0] }
        savedAliases = current.enumerated().filter { !offsets.contains($0.offset) }
            .map { $0.element }.joined(separator: "\n")
        if removed.contains(currentAlias) { currentAlias = "" }
    }

    private var validGmail: Bool {
        let value = gmail.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        return value.hasSuffix("@gmail.com") && value.split(separator: "@").count == 2 && value.count > 10
    }

    private var verifiedTrialURL: URL? {
        let value = trialLink.trimmingCharacters(in: .whitespacesAndNewlines)
        guard let parts = URLComponents(string: value),
              parts.scheme?.lowercased() == "https",
              let host = parts.host?.lowercased(),
              ["chatgpt.com", "www.chatgpt.com", "openai.com", "www.openai.com"].contains(host),
              parts.user == nil, parts.password == nil else { return nil }
        return parts.url
    }

    private func openURL(_ value: String) {
        guard let url = URL(string: value) else { return }
        UIApplication.shared.open(url)
    }

    private func createAlias() {
        guard validGmail else { return }
        let local = gmail.trimmingCharacters(in: .whitespacesAndNewlines).lowercased().split(separator: "@")[0].split(separator: "+")[0]
        let suffix = UUID().uuidString.replacingOccurrences(of: "-", with: "").prefix(10).lowercased()
        let address = String(local) + "+eri" + suffix + "@gmail.com"
        currentAlias = address
        var items = aliases
        items.insert(address, at: 0)
        savedAliases = items.prefix(100).joined(separator: "\n")
        UIPasteboard.general.string = address
    }
}


// Shared manual billing details for the device owner.
// All fields are saved on this device in the iOS Keychain, never in GitHub or a server.
// This does not link a payment method to a Google or ChatGPT account.
struct BillingProfile: Codable {
    var email = ""
    var fullName = ""
    var country = "Ấn Độ"
    var addressLine1 = ""
    var addressLine2 = ""
    var city = ""
    var postalCode = ""
    var region = ""
    var upiID = ""
}

enum BillingProfileKeychain {
    private static let service = "com.erimail.billing.profile.v1"
    private static let account = "device-owner"

    private static var query: [String: Any] {
        [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account
        ]
    }

    static func load() -> BillingProfile {
        var options = query
        options[kSecReturnData as String] = kCFBooleanTrue
        options[kSecMatchLimit as String] = kSecMatchLimitOne
        var result: CFTypeRef?
        guard SecItemCopyMatching(options as CFDictionary, &result) == errSecSuccess,
              let data = result as? Data,
              let profile = try? JSONDecoder().decode(BillingProfile.self, from: data)
        else { return BillingProfile() }
        return profile
    }

    static func save(_ profile: BillingProfile) -> Bool {
        guard let data = try? JSONEncoder().encode(profile) else { return false }
        let attributes = [kSecValueData as String: data]
        let updateStatus = SecItemUpdate(query as CFDictionary, attributes as CFDictionary)
        if updateStatus == errSecSuccess { return true }
        guard updateStatus == errSecItemNotFound else { return false }
        var insert = query
        insert[kSecValueData as String] = data
        insert[kSecAttrAccessible as String] = kSecAttrAccessibleWhenUnlockedThisDeviceOnly
        return SecItemAdd(insert as CFDictionary, nil) == errSecSuccess
    }

    static func remove() -> Bool {
        let status = SecItemDelete(query as CFDictionary)
        return status == errSecSuccess || status == errSecItemNotFound
    }
}

struct BillingProfileView: View {
    @State private var profile = BillingProfileKeychain.load()
    @State private var notice = ""
    @State private var showDeleteConfirmation = false

    private var hasUPI: Bool {
        !profile.upiID.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
    }

    private var addressText: String {
        [profile.addressLine1, profile.addressLine2, profile.city, profile.region,
         profile.postalCode, profile.country]
        .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
        .filter { !$0.isEmpty }
        .joined(separator: ", ")
    }

    private var fullText: String {
        [
            "Email: " + profile.email,
            "Tên: " + profile.fullName,
            "Địa chỉ: " + addressText,
            "UPI: " + profile.upiID
        ].joined(separator: "\n")
    }

    var body: some View {
        Form {
            Section {
                Text("Nhập thông tin một lần, lưu trên iPhone và sao chép khi điền biểu mẫu cho tài khoản của chính bạn.")
                    .font(.footnote)
                    .foregroundColor(.secondary)
            }
            Section("Thông tin thanh toán") {
                TextField("Email thanh toán", text: $profile.email)
                    .keyboardType(.emailAddress)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
                TextField("Họ và tên", text: $profile.fullName)
                TextField("Quốc gia hoặc khu vực", text: $profile.country)
                TextField("Dòng địa chỉ 1", text: $profile.addressLine1)
                TextField("Dòng địa chỉ 2 (không bắt buộc)", text: $profile.addressLine2)
                TextField("Thành phố", text: $profile.city)
                TextField("Mã PIN / bưu điện", text: $profile.postalCode)
                    .keyboardType(.numbersAndPunctuation)
                TextField("Tiểu bang / tỉnh", text: $profile.region)
                TextField("UPI ID", text: $profile.upiID)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
            }
            Section("Lưu và sao chép") {
                Button {
                    notice = BillingProfileKeychain.save(profile)
                        ? "Đã lưu hồ sơ trong Keychain trên iPhone."
                        : "Không lưu được hồ sơ. Hãy thử mở khóa thiết bị và thực hiện lại."
                } label: {
                    Label("Lưu hồ sơ", systemImage: "lock.shield")
                }
                .buttonStyle(.borderedProminent)

                Button("Sao chép UPI ID") {
                    UIPasteboard.general.string = profile.upiID
                    notice = "Đã sao chép UPI ID."
                }
                .disabled(!hasUPI)

                Button("Sao chép địa chỉ") {
                    UIPasteboard.general.string = addressText
                    notice = "Đã sao chép địa chỉ."
                }
                .disabled(addressText.isEmpty)

                Button("Sao chép toàn bộ hồ sơ") {
                    UIPasteboard.general.string = fullText
                    notice = "Đã sao chép thông tin hồ sơ."
                }

                Button {
                    if let url = URL(string: "https://chatgpt.com/") {
                        UIApplication.shared.open(url)
                    }
                } label: {
                    Label("Mở ChatGPT chính thức", systemImage: "arrow.up.right.square")
                }

                Button("Xóa hồ sơ khỏi iPhone", role: .destructive) {
                    showDeleteConfirmation = true
                }
            }
            Section("Quyền riêng tư") {
                Text("Hồ sơ chỉ lưu trong Keychain của thiết bị này, không gửi lên máy chủ Eri Mail hay GitHub. Thông tin bạn sao chép sẽ nằm tạm trong bộ nhớ tạm iOS.")
                    .font(.footnote)
                    .foregroundColor(.secondary)
                Text("Ứng dụng không tự thêm UPI vào ChatGPT hay Google, không tự thanh toán và không tự kích hoạt Plus hoặc dùng thử.")
                    .font(.footnote)
                    .foregroundColor(.secondary)
            }
            if !notice.isEmpty {
                Section {
                    Text(notice)
                        .font(.footnote)
                        .foregroundColor(.secondary)
                        .accessibilityAddTraits(.updatesFrequently)
                }
            }
        }
        .onAppear { profile = BillingProfileKeychain.load() }
        .confirmationDialog("Xóa hồ sơ đã lưu trên iPhone?", isPresented: $showDeleteConfirmation, titleVisibility: .visible) {
            Button("Xóa hồ sơ", role: .destructive) {
                if BillingProfileKeychain.remove() {
                    profile = BillingProfile()
                    notice = "Đã xóa hồ sơ trên iPhone."
                } else {
                    notice = "Không xóa được hồ sơ. Thử lại sau."
                }
            }
        }
    }
}


// App Store public listing scanner. This uses the documented iTunes Search API.
// App Store listing metadata contains no individual offer codes or subscription
// entitlements, so this UI never invents one or claims that a code is valid.
struct AppStoreCatalogResponse: Decodable {
    let resultCount: Int
    let results: [AppStoreCatalogApp]
}

struct AppStoreCatalogApp: Decodable {
    let trackId: Int
    let trackName: String?
    let sellerName: String?
    let version: String?
    let trackViewUrl: String?
    let formattedPrice: String?
}

@MainActor final class AppStoreOfferScanner: ObservableObject {
    @Published var busy = false
    @Published var app: AppStoreCatalogApp?
    @Published var appID: String?
    @Published var message = "Bước 1: Dán đường dẫn App Store rồi chọn Quét."
    @Published var didScan = false

    static func parseLink(_ raw: String) -> (id: String, country: String)? {
        let raw = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        guard let url = URLComponents(string: raw),
              url.scheme?.lowercased() == "https",
              url.host?.lowercased() == "apps.apple.com",
              url.user == nil, url.password == nil
        else { return nil }
        let path = url.path as NSString
        guard let regex = try? NSRegularExpression(pattern: "/id([0-9]{7,})"),
              let match = regex.firstMatch(in: url.path, range: NSRange(location: 0, length: path.length))
        else { return nil }
        let id = path.substring(with: match.range(at: 1))
        let first = url.path.split(separator: "/").first.map(String.init) ?? "vn"
        let country = first.count == 2 && first.range(of: "^[a-zA-Z]{2}$", options: .regularExpression) != nil
            ? first.lowercased() : "vn"
        return (id, country)
    }

    func scan(_ raw: String) async {
        guard !busy else { return }
        app = nil; appID = nil; didScan = false
        guard let parsed = Self.parseLink(raw) else {
            message = "Liên kết không hợp lệ. Dùng URL HTTPS của apps.apple.com có mã id ứng dụng."
            return
        }
        guard let idNumber = Int(parsed.id) else {
            message = "Mã ứng dụng không hợp lệ."
            return
        }
        busy = true
        defer { busy = false }
        do {
            var url = URLComponents(string: "https://itunes.apple.com/lookup")!
            url.queryItems = [
                URLQueryItem(name: "id", value: parsed.id),
                URLQueryItem(name: "country", value: parsed.country),
                URLQueryItem(name: "entity", value: "software")
            ]
            guard let lookupURL = url.url else {
                message = "Không tạo được URL tra cứu."
                return
            }
            var req = URLRequest(url: lookupURL)
            req.timeoutInterval = 20
            let (data, response) = try await URLSession.shared.data(for: req)
            guard let http = response as? HTTPURLResponse, (200...299).contains(http.statusCode) else {
                message = "App Store không trả về dữ liệu hợp lệ. Hãy thử lại."
                return
            }
            let result = try JSONDecoder().decode(AppStoreCatalogResponse.self, from: data)
            guard let found = result.results.first(where: { $0.trackId == idNumber }) else {
                message = "Không tìm thấy ứng dụng với mã này tại khu vực đã chọn."
                return
            }
            app = found
            appID = parsed.id
            didScan = true
            message = "Đã quét xong thông tin ứng dụng công khai. API App Store không cung cấp mã giảm giá hay trạng thái đủ điều kiện nhận ưu đãi; chưa xác nhận có mã nào cho ứng dụng này."
        } catch {
            message = "Không truy vấn được App Store: " + error.localizedDescription
        }
    }
}

struct AppStoreOffersView: View {
    @StateObject private var scanner = AppStoreOfferScanner()
    @State private var appLink = "https://apps.apple.com/vn/app/chatgpt/id6448311069?l=vi"
    @State private var enteredCode = ""

    private var redemptionURL: URL? {
        let normalized = enteredCode.trimmingCharacters(in: .whitespacesAndNewlines)
        guard let id = scanner.appID,
              (4...64).contains(normalized.count),
              normalized.range(of: "^[A-Za-z0-9-]+$", options: .regularExpression) != nil
        else { return nil }
        var link = URLComponents(string: "https://apps.apple.com/redeem")!
        link.queryItems = [
            URLQueryItem(name: "ctx", value: "offercodes"),
            URLQueryItem(name: "id", value: id),
            URLQueryItem(name: "code", value: normalized)
        ]
        return link.url
    }

    private func openURL(_ url: URL?) {
        guard let url else { return }
        UIApplication.shared.open(url)
    }

    private var publicSearchURL: URL? {
        guard scanner.appID != nil else { return nil }
        var url = URLComponents(string: "https://www.google.com/search")!
        let title = scanner.app?.trackName ?? "ChatGPT"
        url.queryItems = [
            URLQueryItem(name: "q", value: "\(title) Apple App Store official offer code promotion")
        ]
        return url.url
    }

    var body: some View {
        Form {
            Section("B1 · Nhập link App Store") {
                TextField("https://apps.apple.com/vn/app/...", text: $appLink)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
                    .keyboardType(.URL)
                Button {
                    Task { await scanner.scan(appLink) }
                } label: {
                    Label(scanner.busy ? "Đang quét..." : "Quét ứng dụng", systemImage: "magnifyingglass")
                }
                .disabled(scanner.busy)
                if scanner.busy { ProgressView() }
            }
            Section("B2 · Tìm ưu đãi công khai") {
                if let app = scanner.app {
                    Text(app.trackName ?? "Ứng dụng")
                        .font(.headline)
                    if let seller = app.sellerName { Text("Nhà phát hành: " + seller) }
                    if let version = app.version { Text("Phiên bản: " + version) }
                    Text("Mã App Store: " + String(app.trackId))
                    if let page = app.trackViewUrl, let url = URL(string: page) {
                        Button("Mở trang ứng dụng trên App Store") { openURL(url) }
                    }
                }
                Text(scanner.message)
                    .font(.footnote)
                    .foregroundColor(.secondary)
                Button {
                    openURL(publicSearchURL)
                } label: {
                    Label("Tìm mã được công bố trên web", systemImage: "safari")
                }
                .disabled(!scanner.didScan)
                Text("Kết quả tìm trên web chưa được Eri Mail xác thực. Mã thật phải do chủ ứng dụng phát hành, và có thể chỉ dành cho một số tài khoản hoặc khu vực.")
                    .font(.footnote)
                    .foregroundColor(.secondary)
            }
            Section("B3 · Đổi mã trên App Store") {
                TextField("Nhập mã ưu đãi đã nhận", text: $enteredCode)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
                Button {
                    UIPasteboard.general.string = enteredCode.trimmingCharacters(in: .whitespacesAndNewlines)
                } label: {
                    Label("Sao chép mã khuyến mãi", systemImage: "doc.on.doc")
                }
                .disabled(enteredCode.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                Button {
                    openURL(redemptionURL)
                } label: {
                    Label("Mở trang áp dụng mã chính thức", systemImage: "giftcard")
                }
                .disabled(redemptionURL == nil)
                Text("Nếu có mã hợp lệ, App Store sẽ tự xác định quyền dùng, thời hạn, giá và yêu cầu xác nhận. Eri Mail không thể tự áp dụng mã vào trang thanh toán ChatGPT hoặc bảo đảm được giảm giá.")
                    .font(.footnote)
                    .foregroundColor(.secondary)
                Button("Xem hướng dẫn nhận ưu đãi của OpenAI") {
                    openURL(URL(string: "https://help.openai.com/en/articles/8381046-chatgpt-promotional-subscriptionsfree-trial-invites-faq"))
                }
            }
        }
    }
}


struct IPAExportView: View {
    @StateObject private var scanner = AppStoreOfferScanner()
    @State private var appLink = "https://apps.apple.com/vn/app/roblox-vn/id6474715805?l=vi"
    @State private var directIPA = ""
    @State private var showImporter = false
    @State private var importedIPA: URL?
    @State private var showShare = false
    @State private var errorMessage = ""

    private var validIPAURL: URL? {
        guard let parts = URLComponents(string: directIPA.trimmingCharacters(in: .whitespacesAndNewlines)),
              parts.scheme?.lowercased() == "https",
              parts.user == nil, parts.password == nil,
              let url = parts.url,
              url.path.lowercased().hasSuffix(".ipa")
        else { return nil }
        return url
    }

    var body: some View {
        Form {
            Section("Tra cứu ứng dụng") {
                TextField("Link App Store", text: $appLink)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
                    .keyboardType(.URL)
                Button("Tìm ứng dụng") {
                    Task { await scanner.scan(appLink) }
                }
                .disabled(scanner.busy)
                if scanner.busy { ProgressView() }
                if let app = scanner.app {
                    Text(app.trackName ?? "Ứng dụng")
                        .font(.headline)
                    if let seller = app.sellerName { Text("Nhà phát hành: " + seller) }
                    if let page = app.trackViewUrl, let url = URL(string: page) {
                        Button("Tải / cài từ App Store") { UIApplication.shared.open(url) }
                    }
                }
                Text(scanner.message)
                    .font(.footnote)
                    .foregroundColor(.secondary)
                Text("Link App Store không chứa file IPA tải trực tiếp. Chỉ App Store mới có thể cài ứng dụng từ liên kết này.")
                    .font(.footnote)
                    .foregroundColor(.secondary)
            }
            Section("IPA từ nguồn hợp lệ") {
                TextField("Link HTTPS trực tiếp tới file .ipa", text: $directIPA)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
                    .keyboardType(.URL)
                Button {
                    if let url = validIPAURL { UIApplication.shared.open(url) }
                } label: {
                    Label("Tải IPA từ nguồn đã nhập", systemImage: "arrow.down.circle")
                }
                .disabled(validIPAURL == nil)
                Button {
                    showImporter = true
                } label: {
                    Label("Chọn IPA có sẵn trong Tệp", systemImage: "folder")
                }
                if importedIPA != nil {
                    Button {
                        showShare = true
                    } label: {
                        Label("Xuất / chia sẻ IPA", systemImage: "square.and.arrow.up")
                    }
                }
                if !errorMessage.isEmpty {
                    Text(errorMessage).font(.footnote).foregroundColor(.red)
                }
                Text("Không giải mã ứng dụng App Store hoặc tự ký/cài IPA. Chỉ sử dụng IPA mà bạn có quyền phân phối.")
                    .font(.footnote)
                    .foregroundColor(.secondary)
            }
        }
        .fileImporter(isPresented: $showImporter, allowedContentTypes: [.data]) { result in
            switch result {
            case .success(let url):
                guard url.pathExtension.lowercased() == "ipa" else {
                    errorMessage = "Vui lòng chọn file .ipa"
                    return
                }
                let access = url.startAccessingSecurityScopedResource()
                defer { if access { url.stopAccessingSecurityScopedResource() } }
                let destination = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString + ".ipa")
                do {
                    try FileManager.default.copyItem(at: url, to: destination)
                    importedIPA = destination
                    errorMessage = ""
                } catch {
                    errorMessage = "Không nhập được IPA: " + error.localizedDescription
                }
            case .failure(let error):
                errorMessage = error.localizedDescription
            }
        }
        .sheet(isPresented: $showShare) {
            if let url = importedIPA {
                IPAActivitySheet(items: [url])
            }
        }
    }
}

struct IPAActivitySheet: UIViewControllerRepresentable {
    let items: [Any]
    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: items, applicationActivities: nil)
    }
    func updateUIViewController(_ controller: UIActivityViewController, context: Context) {}
}


struct SigningToolsView: View {
    private let toolNames = ["ESign", "Feather", "GBox", "Scarlet"]
    @State private var selectedTool = "ESign"
    @State private var ipaURLText = ""
    @State private var showImporter = false
    @State private var showShare = false
    @State private var selectedFile: URL?
    @State private var notice = ""
    @State private var signedResultText = ""

    private var downloadURL: URL? {
        guard let parts = URLComponents(string: ipaURLText.trimmingCharacters(in: .whitespacesAndNewlines)),
              parts.scheme?.lowercased() == "https",
              parts.user == nil, parts.password == nil,
              let url = parts.url, url.path.lowercased().hasSuffix(".ipa")
        else { return nil }
        return url
    }

    private var validatedSignedResultURL: URL? {
        guard let components = URLComponents(string: signedResultText.trimmingCharacters(in: .whitespacesAndNewlines)),
              components.scheme == "https", components.host == "sign.codevn.net",
              components.path == "/app.php",
              let token = components.queryItems?.first(where: { $0.name == "ipa" })?.value,
              !token.isEmpty, token.count <= 128,
              token.allSatisfy({ $0.isASCII && ($0.isLetter || $0.isNumber) })
        else { return nil }
        return components.url
    }

    var body: some View {
        Form {
            Section("Công cụ ký IPA") {
                Text("Chọn công cụ muốn tải hoặc nhập IPA từ nguồn bạn tin cậy.")
                    .font(.footnote).foregroundColor(.secondary)
                Picker("Ứng dụng", selection: $selectedTool) {
                    ForEach(toolNames, id: \.self) { name in
                        Text(name).tag(name)
                    }
                }
                .pickerStyle(.menu)
                ForEach(toolNames, id: \.self) { name in
                    Button {
                        selectedTool = name
                        selectedFile = nil
                        ipaURLText = ""
                        notice = "Đã chọn " + name + ". Hãy nhập link IPA hợp lệ hoặc chọn file có sẵn."
                    } label: {
                        HStack {
                            Label(name, systemImage: "app.badge")
                            Spacer()
                            if selectedTool == name {
                                Image(systemName: "checkmark").foregroundColor(.blue)
                            }
                        }
                    }
                }
            }
            Section("Tải " + selectedTool + ".ipa") {
                TextField("Link HTTPS trực tiếp tới file .ipa", text: $ipaURLText)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
                    .keyboardType(.URL)
                Button {
                    if let url = downloadURL { UIApplication.shared.open(url) }
                } label: {
                    Label("Mở link tải " + selectedTool + ".ipa", systemImage: "arrow.down.circle")
                }
                .disabled(downloadURL == nil)
                Button {
                    showImporter = true
                } label: {
                    Label("Chọn IPA từ ứng dụng Tệp", systemImage: "folder")
                }
                if selectedFile != nil {
                    Button {
                        showShare = true
                    } label: {
                        Label("Xuất / chia sẻ IPA đã chọn", systemImage: "square.and.arrow.up")
                    }
                }
                Text("Không tự động cung cấp bản IPA chưa xác minh hoặc chứng chỉ ký dùng chung. URL phải được người dùng nhập.")
                    .font(.footnote).foregroundColor(.secondary)
            }
            Section("Ký miễn phí · Apple ID") {
                Text("Miễn phí với Apple ID cá nhân và Xcode trên máy Mac. Xcode có thể tự quản lý chứng chỉ phát triển và hồ sơ cấp phép cho ứng dụng do bạn có quyền ký; không cần tải .p12 hay mật khẩu lên CodeVN.")
                    .font(.footnote)
                Button {
                    if let url = URL(string: "https://developer.apple.com/xcode/") {
                        UIApplication.shared.open(url)
                    }
                } label: {
                    Label("Mở Xcode · Ký miễn phí", systemImage: "checkmark.shield")
                }
                Text("Không ký IPA tự động ngay trên iPhone. Cần Mac và dự án hoặc mã nguồn ứng dụng phù hợp; tài khoản miễn phí có giới hạn thời hạn và tính năng.")
                    .font(.footnote)
                    .foregroundColor(.secondary)
            }
            Section("Eri Nguyễn · Nguồn ESign / KSign") {
                Text("Kho ứng dụng ESign và KSign trong Eri Mail. Danh sách và tệp được cung cấp bởi nguồn bên thứ ba; Eri Nguyễn không sở hữu hoặc xác minh chữ ký của các bản IPA.")
                    .font(.footnote)
                Button {
                    if let url = URL(string: "https://khoindvn.io.vn/install/") {
                        UIApplication.shared.open(url)
                    }
                } label: {
                    Label("Xem danh sách ESign / KSign", systemImage: "square.stack.3d.up")
                }
                Button {
                    if let url = URL(string: "https://website.khoindvn.io.vn/apps.js") {
                        UIApplication.shared.open(url)
                    }
                } label: {
                    Label("Xem dữ liệu nguồn ứng dụng", systemImage: "doc.text")
                }
                Text("Thương hiệu hiển thị: Eri Nguyễn. Các liên kết vẫn sử dụng tên miền của nhà cung cấp gốc; Eri Nguyễn không sở hữu tên miền hoặc dịch vụ đó. Không tự động thực thi JavaScript bên ngoài.")
                    .font(.footnote).foregroundColor(.secondary)
            }
            Section("Ký IPA online · CodeVN") {
                Text("Dịch vụ bên thứ ba có sẵn các lựa chọn ESign, Feather, GBox và Scarlet. Với các lựa chọn này, trang web cho biết không cần tải IPA lên; bạn vẫn cần chứng chỉ .p12, mật khẩu và .mobileprovision.")
                    .font(.footnote)
                Button {
                    if let url = URL(string: "https://sign.codevn.net/") {
                        UIApplication.shared.open(url)
                    }
                } label: {
                    Label("Mở Sign CodeVN để ký IPA", systemImage: "signature")
                }
                Text("Lưu ý: trang web yêu cầu tải chứng chỉ .p12 và hồ sơ cấp phép, kèm mật khẩu .p12, lên máy chủ bên thứ ba. Chỉ tiếp tục nếu bạn tin tưởng dịch vụ và hiểu rủi ro lộ khóa ký. Eri Mail không thu thập hoặc gửi các tệp này.")
                    .font(.footnote)
                    .foregroundColor(.secondary)
                Text("Theo nội dung trang được cung cấp, file IPA đã ký chỉ được lưu khoảng 30 phút. Eri Mail không kiểm chứng hoặc bảo đảm chính sách lưu/xóa của máy chủ.")
                    .font(.footnote)
                    .foregroundColor(.secondary)
            }
            Section("Kết quả ký IPA · CodeVN") {
                Text("Sau khi máy chủ báo ký thành công, dán URL kết quả app.php?ipa=... để hiển thị hai lựa chọn. Đây không phải thao tác ký tự động.")
                    .font(.footnote).foregroundColor(.secondary)
                TextField("https://sign.codevn.net/app.php?ipa=...", text: $signedResultText)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
                    .keyboardType(.URL)
                if let resultURL = validatedSignedResultURL,
                   let token = URLComponents(url: resultURL, resolvingAgainstBaseURL: false)?
                        .queryItems?.first(where: { $0.name == "ipa" })?.value,
                   let ipaURL = URL(string: "https://sign.codevn.net/data/" + token + "/codevndotnet-signed.ipa"),
                   let manifestURL = URL(string: "https://sign.codevn.net/data/" + token + "/codevndotnet.plist"),
                   let installURL = URL(string: "itms-services://?action=download-manifest&url=" + manifestURL.absoluteString) {
                    Button {
                        UIApplication.shared.open(installURL)
                    } label: {
                        Label("Cài đặt trực tiếp", systemImage: "iphone.gen3")
                    }
                    Button {
                        UIApplication.shared.open(ipaURL)
                    } label: {
                        Label("Tải IPA đã ký", systemImage: "arrow.down.to.line")
                    }
                    Text("Đường dẫn được dựng theo mẫu HTML CodeVN đã cung cấp. Chỉ hoạt động khi máy chủ đã ký thành công, file còn tồn tại và thiết bị cho phép cài đặt.")
                        .font(.footnote).foregroundColor(.secondary)
                } else {
                    Text("Hai nút sẽ xuất hiện khi có liên kết kết quả hợp lệ.")
                        .font(.footnote).foregroundColor(.secondary)
                }
            }
            Section("Ký và cài đặt") {
                Text("1. Ưu tiên ký miễn phí bằng Apple ID với Xcode trên Mac, hoặc chọn công cụ ký có chứng chỉ hợp lệ.")
                Text("2. Chuẩn bị IPA và chứng chỉ mà bạn có quyền sử dụng.")
                Text("3. Mở công cụ đã cài, nhập IPA, ký rồi làm theo hướng dẫn.")
                Text("Eri Mail không thể tự ký hoặc cài trực tiếp IPA chưa được ký hợp lệ.")
                    .font(.footnote).foregroundColor(.secondary)
            }
            if !notice.isEmpty {
                Section { Text(notice).font(.footnote).foregroundColor(.secondary) }
            }
        }
        .fileImporter(isPresented: $showImporter, allowedContentTypes: [.data]) { result in
            switch result {
            case .success(let url):
                guard url.pathExtension.lowercased() == "ipa" else {
                    notice = "Chỉ hỗ trợ file .ipa"
                    return
                }
                let access = url.startAccessingSecurityScopedResource()
                defer { if access { url.stopAccessingSecurityScopedResource() } }
                let destination = FileManager.default.temporaryDirectory
                    .appendingPathComponent(UUID().uuidString + ".ipa")
                do {
                    try FileManager.default.copyItem(at: url, to: destination)
                    selectedFile = destination
                    notice = "Đã nhập " + url.lastPathComponent + " để chia sẻ. Chưa xác minh chữ ký hoặc nguồn gốc."
                } catch {
                    notice = "Không nhập được IPA: " + error.localizedDescription
                }
            case .failure(let error):
                notice = error.localizedDescription
            }
        }
        .sheet(isPresented: $showShare) {
            if let url = selectedFile {
                IPAActivitySheet(items: [url])
            }
        }
    }
}

struct CertificatesView: View {
    @State private var showImporter = false
    @State private var fileName = ""
    @State private var notice = ""

    var body: some View {
        Form {
            Section("Chứng chỉ miễn phí") {
                Text("Apple ID miễn phí có thể dùng Xcode ký ứng dụng để phát triển và kiểm thử cá nhân trên thiết bị được hỗ trợ. Đây không phải chứng chỉ phát hành IPA miễn phí dùng chung.")
                Button {
                    UIApplication.shared.open(URL(string: "https://developer.apple.com/xcode/")!)
                } label: {
                    Label("Tìm hiểu ký miễn phí với Xcode", systemImage: "safari")
                }
                Text("Không cung cấp chứng chỉ công khai hoặc chứng chỉ bị thu hồi.")
                    .font(.footnote).foregroundColor(.secondary)
            }
            Section("Chứng chỉ trả phí") {
                Text("Apple Developer Program là lựa chọn chính thức để đăng ký quyền phát triển và phân phối ứng dụng theo điều kiện của Apple.")
                Button {
                    UIApplication.shared.open(URL(string: "https://developer.apple.com/programs/")!)
                } label: {
                    Label("Xem Apple Developer Program", systemImage: "safari")
                }
                Text("Không thể mua chứng chỉ ký IPA trực tiếp bằng App Store. Giá và điều kiện đăng ký được Apple công bố tại trang chính thức.")
                    .font(.footnote).foregroundColor(.secondary)
            }
            Section("Chứng chỉ của bạn") {
                Button {
                    showImporter = true
                } label: {
                    Label("Chọn chứng chỉ / hồ sơ cấp phép", systemImage: "doc.badge.plus")
                }
                if !fileName.isEmpty {
                    Text("Đã chọn: " + fileName)
                }
                Text("Chỉ xem tên file .p12, .pfx, .cer, .mobileprovision; không đọc, lưu hoặc gửi khóa riêng và mật khẩu.")
                    .font(.footnote).foregroundColor(.secondary)
                if !notice.isEmpty {
                    Text(notice).font(.footnote).foregroundColor(.secondary)
                }
            }
        }
        .fileImporter(isPresented: $showImporter, allowedContentTypes: [.data]) { result in
            switch result {
            case .success(let url):
                let allowed = ["p12", "pfx", "cer", "mobileprovision"]
                if allowed.contains(url.pathExtension.lowercased()) {
                    fileName = url.lastPathComponent
                    notice = "Chỉ ghi nhận tên file trong phiên hiện tại. Nhập chứng chỉ vào công cụ ký đáng tin cậy để sử dụng."
                } else {
                    notice = "Định dạng không được hỗ trợ."
                }
            case .failure(let error):
                notice = error.localizedDescription
            }
        }
    }
}


// Opens the third-party CodeVN injector in a sandboxed Safari view.
// No IPA, dylib or certificate is uploaded by Eri Mail itself.
struct InjectDylibView: View {
    @State private var showCodeVN = false
    private let codeVNURL = URL(string: "https://ipatool.codevn.net/inject-dylib/")!

    var body: some View {
        Form {
            Section("CodeVN · Inject Dylib Online") {
                Text("Tiêm dylib/deb vào IPA bằng công cụ web của CodeVN. File được tải lên máy chủ CodeVN, không xử lý trong Eri Mail.")
                Button {
                    showCodeVN = true
                } label: {
                    Label("Mở công cụ Inject Dylib", systemImage: "safari")
                }
                Button {
                    UIApplication.shared.open(codeVNURL)
                } label: {
                    Label("Mở bằng Safari", systemImage: "arrow.up.right.square")
                }
            }
            Section("Các chức năng trên CodeVN") {
                Label("Chọn file IPA, dylib hoặc deb", systemImage: "doc.zipper")
                Label("Đổi icon, phiên bản, Bundle ID, tên ứng dụng", systemImage: "slider.horizontal.3")
                Label("Tùy chọn Document Browser, Extensions, Watch", systemImage: "square.stack.3d.up")
                Label("Chọn đường dẫn inject @rpath hoặc @executable_path", systemImage: "point.3.connected.trianglepath.dotted")
            }
            Section("Lưu ý trước khi tải lên") {
                Text("Theo thông tin trang CodeVN được cung cấp: chỉ hỗ trợ IPA đã giải mã, tối đa 2048 MB; file kết quả bị xóa sau 15 phút.")
                Text("Không tải lên IPA chứa dữ liệu cá nhân, khóa ký hoặc nội dung bạn không có quyền sửa đổi. Không bảo đảm IPA sau inject hoạt động hoặc cài được.")
                    .foregroundColor(.secondary)
            }
        }
        .sheet(isPresented: $showCodeVN) {
            CodeVNSafariView(url: codeVNURL)
        }
    }
}

struct CodeVNSafariView: UIViewControllerRepresentable {
    let url: URL
    func makeUIViewController(context: Context) -> SFSafariViewController {
        SFSafariViewController(url: url)
    }
    func updateUIViewController(_ controller: SFSafariViewController, context: Context) {}
}
